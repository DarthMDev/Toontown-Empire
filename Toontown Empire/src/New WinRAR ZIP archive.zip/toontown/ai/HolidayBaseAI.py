from direct.directnotify.DirectNotifyGlobal import *


class HolidayBaseAI:
    def __init__(self, air, holidayId):
        self.air = air
        self.holidayId = holidayId

    def start(self):
        pass

    def stop(self):
        pass
