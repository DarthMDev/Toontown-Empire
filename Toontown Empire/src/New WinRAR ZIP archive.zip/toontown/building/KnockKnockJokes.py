from toontown.toonbase import TTLocalizer
KnockKnockJokes = TTLocalizer.KnockKnockJokes
