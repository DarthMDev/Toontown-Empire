from DistributedToonInteriorAI import *

class DistributedToonHallInteriorAI(DistributedToonInteriorAI):
    pass
