from toontown.toonbase import TTLocalizer
toonHealJokes = TTLocalizer.ToonHealJokes
