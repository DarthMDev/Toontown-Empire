from direct.directnotify import DirectNotifyGlobal
from direct.task import Task
import DistributedSwitchAI

class DistributedTriggerAI(DistributedSwitchAI.DistributedSwitchAI):
    pass
