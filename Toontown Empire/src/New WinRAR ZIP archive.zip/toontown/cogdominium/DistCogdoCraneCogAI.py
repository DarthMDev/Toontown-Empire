from direct.directnotify import DirectNotifyGlobal
from direct.distributed.DistributedObjectAI import DistributedObjectAI

class DistCogdoCraneCogAI(DistributedObjectAI):
    notify = DirectNotifyGlobal.directNotify.newCategory("DistCogdoCraneCogAI")

    def setGameId(self, todo0):
        pass

    def setDNAString(self, todo0):
        pass

    def setSpawnInfo(self, todo0, todo1):
        pass
