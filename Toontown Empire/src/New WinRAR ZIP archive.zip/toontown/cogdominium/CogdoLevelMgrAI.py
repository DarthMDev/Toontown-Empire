from otp.level import LevelMgrAI

class CogdoLevelMgrAI(LevelMgrAI.LevelMgrAI):
    pass
