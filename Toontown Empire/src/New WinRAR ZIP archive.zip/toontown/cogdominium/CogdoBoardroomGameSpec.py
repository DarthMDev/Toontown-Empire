from toontown.coghq.SpecImports import *
GlobalEntities = {1000: {'type': 'levelMgr',
        'name': 'LevelMgr',
        'comment': '',
        'parentEntId': 0,
        'modelFilename': 'phase_10/models/cogHQ/EndVault.bam'},
 0: {'type': 'zone',
     'name': 'UberZone',
     'comment': '',
     'parentEntId': 0,
     'scale': 1,
     'description': '',
     'visibility': []},
 10000: {'type': 'cogdoBoardroomGameSettings',
         'name': '<unnamed>',
         'comment': '',
         'parentEntId': 0,
         'TimerScale': 0.5028702719683693}}
Scenario0 = {}
levelSpec = {'globalEntities': GlobalEntities,
 'scenarios': [Scenario0]}
